# Submission "grader"

Returns either "PASS", "FAIL" or "ERROR" after a while.

Build using `build.sh` or by running the command
`docker build -t grader-image .` in the "grader-image" folder.
