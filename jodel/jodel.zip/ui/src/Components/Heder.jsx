export default function Header() {
    return (
        <div className="header">
        <h1>Welcome to the Live Messages Room!</h1>
        </div>
    );
}